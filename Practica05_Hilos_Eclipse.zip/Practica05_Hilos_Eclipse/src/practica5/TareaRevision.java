package practica5;
import javax.swing.SwingUtilities;import java.util.function.Consumer;
public class TareaRevision implements Runnable {
 private final Mecanico mecanico;private final Consumer<Mecanico> callback;
 public TareaRevision(Mecanico m,Consumer<Mecanico> callback){this.mecanico=m;this.callback=callback;}
 @Override public void run(){try{Thread.sleep(java.util.concurrent.ThreadLocalRandom.current().nextInt(3001));SwingUtilities.invokeLater(()->callback.accept(mecanico));}catch(InterruptedException ex){Thread.currentThread().interrupt();}}
}
