package practica5;
import java.util.*;
public class Mecanico {
 public final String nombre; public final List<Vehiculo> vehiculos=new ArrayList<>();
 public Mecanico(String nombre){this.nombre=nombre;}
 public double porcentajeLote(){return vehiculos.isEmpty()?0:100.0*vehiculos.stream().filter(Vehiculo::requiereArreglo).count()/vehiculos.size();}
 public double porcentajeFallas(String gas){int n=0;for(Vehiculo v:vehiculos){if((gas.equals("Lambda")&&v.fallaLambda())||(gas.equals("O2")&&v.fallaO2())||(gas.equals("N2O")&&v.fallaN2O())||(gas.equals("CO2")&&v.fallaCO2()))n++;}return vehiculos.isEmpty()?0:100.0*n/vehiculos.size();}
 public boolean aprobado(){return porcentajeFallas("Lambda")<=70 && porcentajeFallas("O2")<=30 && porcentajeFallas("N2O")<=80 && porcentajeFallas("CO2")<=50;}
 public String resultado(){return aprobado()?"Pasa en Primera Revisión":"Segunda Revisión Asignada";}
}
