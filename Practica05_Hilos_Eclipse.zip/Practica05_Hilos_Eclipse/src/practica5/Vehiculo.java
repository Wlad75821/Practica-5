package practica5;
public class Vehiculo {
 public final String marca, placa; public final double lambda,o2,n2o,co2;
 public Vehiculo(String marca,String placa,double lambda,double o2,double n2o,double co2){this.marca=marca;this.placa=placa;this.lambda=lambda;this.o2=o2;this.n2o=n2o;this.co2=co2;}
 public boolean fallaLambda(){return lambda>1;} public boolean fallaO2(){return o2>=2;} public boolean fallaN2O(){return n2o>=40;} public boolean fallaCO2(){return co2>=15;}
 public int errores(){return (fallaLambda()?1:0)+(fallaO2()?1:0)+(fallaN2O()?1:0)+(fallaCO2()?1:0);}
 public boolean requiereArreglo(){return errores()>0;}
 public double porcentajeError(){return errores()*25.0;}
}
