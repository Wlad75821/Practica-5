package practica5;
import javax.swing.*;import javax.swing.table.DefaultTableModel;import java.awt.*;import java.util.*;import java.util.List;
public class VentanaPrincipal extends JFrame {
 private final JComboBox<String> selector=new JComboBox<>();
 private final DefaultTableModel modelo=new DefaultTableModel(new Object[]{"Marca","Placa","Lambda","O2","N2O","CO2","Errores (%)","Estado"},0){public boolean isCellEditable(int r,int c){return false;}};
 private final JTable tabla=new JTable(modelo);private final JTextArea resumen=new JTextArea(8,55);
 private final JButton boton=new JButton("Iniciar revisión concurrente");private final JLabel progreso=new JLabel("Listo para iniciar");
 private final Map<String,Mecanico> completados=new LinkedHashMap<>();private List<Mecanico> mecanicos;
 public VentanaPrincipal(){super("Práctica 05 - Revisión vehicular con hilos");setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(1050,600);setLocationRelativeTo(null);
  JPanel superior=new JPanel(new FlowLayout(FlowLayout.LEFT));superior.add(boton);superior.add(new JLabel("Mecánico:"));superior.add(selector);superior.add(progreso);
  add(superior,BorderLayout.NORTH);add(new JScrollPane(tabla),BorderLayout.CENTER);resumen.setEditable(false);resumen.setFont(new Font(Font.MONOSPACED,Font.PLAIN,12));add(new JScrollPane(resumen),BorderLayout.SOUTH);
  boton.addActionListener(e->iniciar());selector.addActionListener(e->mostrar());
 }
 private void iniciar(){boton.setEnabled(false);selector.removeAllItems();completados.clear();modelo.setRowCount(0);resumen.setText("Consultando datos con 10 hilos...\n");progreso.setText("0/10 lotes");
  try{mecanicos=new Repositorio().cargar();for(Mecanico m:mecanicos){new Thread(new TareaRevision(m,this::recibir),"Hilo-"+m.nombre.replace(' ','-')).start();}}
  catch(Exception ex){boton.setEnabled(true);JOptionPane.showMessageDialog(this,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
 }
 private void recibir(Mecanico m){completados.put(m.nombre,m);selector.addItem(m.nombre);progreso.setText(completados.size()+"/10 lotes recibidos");selector.setSelectedItem(m.nombre);
  if(completados.size()==10){boton.setEnabled(true);progreso.setText("10/10 lotes completados");}}
 private void mostrar(){String nombre=(String)selector.getSelectedItem();if(nombre==null||!completados.containsKey(nombre))return;
  Mecanico m=completados.get(nombre);modelo.setRowCount(0);
  for(Vehiculo v:m.vehiculos)modelo.addRow(new Object[]{v.marca,v.placa,v.lambda,v.o2,v.n2o,v.co2,String.format("%.0f%%",v.porcentajeError()),v.requiereArreglo()?"Requiere arreglo":"Sin fallas"});
  resumen.setText("MECÁNICO: "+m.nombre+" | AUTOS: "+m.vehiculos.size()+"\n"+
   String.format("Vehículos con errores: %.1f%% | Lambda: %.1f%% (máx. 70%%) | O2: %.1f%% (máx. 30%%)\nN2O: %.1f%% (máx. 80%%) | CO2: %.1f%% (máx. 50%%)\nRESULTADO DEL LOTE: %s\n",m.porcentajeLote(),m.porcentajeFallas("Lambda"),m.porcentajeFallas("O2"),m.porcentajeFallas("N2O"),m.porcentajeFallas("CO2"),m.resultado())+
   "Reglas: Lambda > 1; O2 >= 2; N2O >= 40; CO2 >= 15.\nLos porcentajes por gas son sobre 5 vehículos; error por auto sobre 4 parámetros.");
 }
}
