package practica5;
import java.io.*;import java.nio.charset.StandardCharsets;import java.nio.file.*;import java.util.*;
public class Repositorio {
 private final Path carpeta=Paths.get("datos");
 public List<Mecanico> cargar() throws IOException {
  Files.createDirectories(carpeta);Path m=carpeta.resolve("mecanicos.txt"),v=carpeta.resolve("vehiculos.txt");
  if(!Files.exists(m)||!Files.exists(v))generar(m,v);
  List<String> nombres=Files.readAllLines(m,StandardCharsets.UTF_8),autos=Files.readAllLines(v,StandardCharsets.UTF_8);
  if(nombres.size()!=10||autos.size()!=50)throw new IOException("Se requieren 10 mecánicos y 50 vehículos.");
  List<Mecanico> lista=new ArrayList<>();Random random=new Random(2026);
  for(String nombre:nombres){if(nombre.trim().isEmpty())throw new IOException("Mecánico vacío");lista.add(new Mecanico(nombre.trim()));}
  Set<String> placas=new HashSet<>();
  for(int i=0;i<autos.size();i++){
   String[] partes=autos.get(i).split(";");if(partes.length!=2||!placas.add(partes[1].trim()))throw new IOException("Registro de vehículo inválido o placa repetida: "+autos.get(i));
   Vehiculo veh=new Vehiculo(partes[0].trim(),partes[1].trim(),redondear(0.85+random.nextDouble()*.40),redondear(random.nextDouble()*3.5),redondear(random.nextDouble()*65),redondear(random.nextDouble()*25));
   lista.get(i/5).vehiculos.add(veh);
  }return lista;
 }
 private double redondear(double d){return Math.round(d*100.0)/100.0;}
 private void generar(Path m,Path v)throws IOException{
  List<String> nombres=new ArrayList<>(),autos=new ArrayList<>();String[] marcas={"Toyota","Chevrolet","Kia","Hyundai","Nissan","Mazda","Ford","Volkswagen","Suzuki","Renault"};
  for(int i=1;i<=10;i++)nombres.add("Mecánico "+i);
  for(int i=0;i<50;i++)autos.add(marcas[i%10]+";PCH-"+String.format("%04d",i+1));
  Files.write(m,nombres,StandardCharsets.UTF_8);Files.write(v,autos,StandardCharsets.UTF_8);
 }
}
